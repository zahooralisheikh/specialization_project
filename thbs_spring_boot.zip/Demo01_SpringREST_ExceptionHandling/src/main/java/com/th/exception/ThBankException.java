package com.th.exception;

public class ThBankException extends Exception {

	private static final long serialVersionUID = 1L;

	public ThBankException(String message) {
		super(message);
		
	}
	
}
