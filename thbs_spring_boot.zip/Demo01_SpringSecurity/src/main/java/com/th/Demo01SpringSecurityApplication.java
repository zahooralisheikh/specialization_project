package com.th;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo01SpringSecurityApplication {
	public static void main(String[] args) {
		SpringApplication.run(Demo01SpringSecurityApplication.class, args);
	}
}
